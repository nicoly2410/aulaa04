import java.ultil.sca
  
public class Main {
  public static void main(String[] args) {
    scanner scanner = new scanner(System.in);

    Double num1;
    Double num2;
    string operacao;
    
    System.out.println("Digite o primeiro numero: ");
    num1 = scanner.nextDouble();

    system.out.println("Digite a operação ( + - * / ): ");
    operacao = scanner.next();

    system.out.println("Digite o segundo numero");
    num2 = scanner.nextDouble();

    //Realizando a operacao escolhida pelo metodo calcule
    System.out.println("Resultado: " + calculo(num1, operacao,num2);

    scanner.close();
  }

  public static Double calculo(Double num1, String operacao, Double num2){
    Double resposta = 0.0;

    if(operacao.equals("+")){
      resultado = num1 + num2;
    }else if (operacao.equals("-")){
      resultado = num1 - num2;
    }else if (operacao.equals("/")){
      resultado = num1 / num2;
    }else if (operacao.equals("*")){
      resultado = num1 * num2;
    }
      
    return resposta; 

  
  }
}